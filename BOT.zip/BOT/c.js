const Discord = require('discord.js');

const bot = new Discord.Client();

const config = require("./config.json");

const PREFIX = '!';
const talkedRecently = new Set();

let cookie = require("./cookies.json");

bot.on('ready', async() =>{ console.log('Bot is Online')
    bot.user.setActivity("Cookies", {type:"PLAYING"})
})

bot.on('message', msg =>{
	if(msg.author.bot) return;
	let Userbal = cookie[msg.author.id].Cookies
	
	let args = msg.content.substring(PREFIX.length).split(" ");
	
	if(!cookie[msg.author.id]){
		cookie[msg.author.id] = {
			Cookies: 1
		}
	}
	if(!msg.content.startsWith(PREFIX)){ if(talkedRecently.has(msg.author.id)) { return
	
	}else 
			{
		cookie[msg.author.id].Cookies = cookie[msg.author.id].Cookies + 1;
	
	fs.writeFile("./cookies.json", JSON.stringify(cookie), (err)=>{
		
		if(err) console.log(err)
	})
			console.log(`${cookie[msg.author.id]}`)
			talkedRecently.add(msg.author.id);
			setTimeout(() => {
				talkedRecently.delete(msg.author.id);
			}, 10000);
		}	

}
	switch(args[0]){
		case 'cookie':
		if(!args[1]) return msg.reply(`Cookies: ${Userbal}`);
			Userbal = Userbal - 1
			let mention = msg.mentions.users.first();
			
		if(Userbal < 0) return msg.reply("Mission failed; too broke to rock")
		
		if(mention.bot)	 return msg.reply("Bots cant have cookies, idot!")
		if(mention == msg.author) return msg.reply(`${bot.users.get(mention.id)} gave himself a cookie, STONKS`);

		if(!cookie[mention.id]){
			cookie[mention.id] = {
				Cookies: 1
			}
		}
		cookie[mention.id].Cookies = cookie[mention.id].Cookies + 1
		cookie[msg.author.id].Cookies = Userbal;
		msg.reply(`Gave a cookie to ${bot.users.get(mention.id)}`)
		
		fs.writeFile("./cookies.json", JSON.stringify(cookie), (err)=>{
			if(err) console.log(err)})
	 
	 break;
}
	
})
















bot.login("NzA3NjY4Nzk4ODI3NjU5Mjc0.XrMedw.cAUb1n1I-GcWb48YZpS1u3Wy1_c")