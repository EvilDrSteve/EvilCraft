module.exports = {
	
	name: 'cq',
	description: 'Country Quiz commands',
	execute(msg, args){
		const PREFIX = "!";
				const config = require("../config.json")
				const BotID = "707668798827659274"
				
				let data = require("./GameData.json")
				
				if(msg.content.startsWith(PREFIX + "cq" + " " + "help")){
					var embed = new Discord.RichEmbed()

            .setColor(config.BLUE)

	.setTitle("Help | Country Quiz")

            .setDescription("You can use the following commands:\n ``.cq help`` \n ``.cq invite`` -- invite the person u want to challenge \n ``.cq quit`` -- quit the game \n ``.cq start`` -- (starts the game and gives a random letter to begin) \n ``.cq pause`` (maybe add maybe not, i dont think its worth adding) \n ``.cq accept`` (accept the invite from player)")

            //.setFooter("Replies to this message will be forwarded to the admins")
          
            .setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")
            
            msg.channel.send(embed)
				}else
				
				if(msg.content.startsWith(PREFIX+ "cq" + " " + "invite")){
		
		if(!data[BotID]){
			data[BotID] = {
				Matchstats: 0
			}
		}
		
			if(data[BotID].Matchstats === 1)	return msg.channel.send("Game already in progress")
					var args = msg.content.split(" ").slice(1);
					target = msg.mentions.users.first()
					const filter = m => m.author.id == target.id
					
					msg.channel.send(`${target} you have been challenged by ${msg.author}, \n do ?cq accept or ?cq deny \n Time left: 30 seconds`).then(() => {
						msg.channel.awaitMessages(filter, {
							maxMatches: 1,
							time: 30000,
							errors: ['time']
						}).then(collected => {
							if(collected.first().content == "!cq accept") { 
							msg.channel.send(`${target} has accepted the challenge`)
						
						data[BotID] = {
							Matchstats: 1
						}
						
							fs.writeFile("./GameData.json", JSON.stringify(data), (err)=>{
		if(err) console.log(err)
	})
							}
						})
					})
				}
	}
	
}