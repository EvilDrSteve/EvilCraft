module.exports = {
			name: 'dm',
			description: 'DM members with official messages',
			execute(msg, args){
			
				const PREFIX = "!";
				const config = require("../config.json")
				/*
				
				APPLICATIONS CLOSED
				
				if(msg.content.startsWith(PREFIX + "dm" + " " + "accept")){
				//if not admin then:	
					if(!msg.member.roles.find(r => r.name === "Admins")) return msg.channel.send("You dont have the permissions to use this command!").then(msg => {
						msg.delete(6000);
					});
					
					var args = msg.content.split(" ").slice(1);
					
					var message = msg.content.split(" ").slice(3).join(" ");
					
					var userID = args[1];
					
					let guild = bot.guilds.get(config.SERVER_ID);
					
					if(isNaN(userID)) return msg.channel.send("Please user a proper User ID!").then(msg =>{
						msg.delete(6000);
					});
					if(!args[2]) return msg.channel.send("You cannot send an empty message!").then(msg =>{
						msg.delete(6000);
					});
					if(!guild.member(userID)) return msg.channel.send("That user is not in the server!").then(msg =>{
						msg.delete(6000);
					});
					
					var userName = bot.users.get(userID).tag

        var embed = new Discord.RichEmbed()

            .setColor(config.GREEN)

	.setTitle("Applications | EvilCraftRealm")

            .setDescription(message)

            .setFooter("Replies to this message will be forwarded to the admins")
          
            .setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")

        bot.users.get(userID).send(embed).catch(console.log(`Message was sent to ${userName}!`))

        if (msg.author.bot) return;

        msg.channel.send("Your Message was Sent!").catch(console.error)
				}else
				
				if(msg.content.startsWith(PREFIX + "dm" + " " + "reject")){
				//if not admin then:	
					if(!msg.member.roles.find(r => r.name === "Admins")) return msg.channel.send("You dont have the permissions to use this command!").then(msg => {
						msg.delete(6000);
					});
					
					var args = msg.content.split(" ").slice(1);
					
					var message = msg.content.split(" ").slice(3).join(" ");
					
					var userID = args[1];
					
					let guild = bot.guilds.get(config.SERVER_ID);
					
					if(isNaN(userID)) return msg.channel.send("Please user a proper User ID!").then(msg =>{
						msg.delete(6000);
					});
					if(!args[2]) return msg.channel.send("You cannot send an empty message!").then(msg =>{
						msg.delete(6000);
					});
					if(!guild.member(userID)) return msg.channel.send("That user is not in the server!").then(msg =>{
						msg.delete(6000);
					});
					
					var userName = bot.users.get(userID).tag

        var embed = new Discord.RichEmbed()

            .setColor(config.RED)

	.setTitle("Applications | EvilCraftRealm")

            .setDescription(message)

            .setFooter("Replies to this message will be forwarded to the admins")
          
            .setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")

        bot.users.get(userID).send(embed).catch(console.log(`Message was sent to ${userName}!`))

        if (msg.author.bot) return;

        msg.channel.send("Your Message was Sent!").catch(console.error)
				}else*/
				
				if(msg.content.startsWith(PREFIX + "dm")){
				//if not admin then:	
					if(!msg.member.roles.find(r => r.name === "Admins")) return msg.channel.send("You dont have the permissions to use this command!").then(msg => {
						msg.delete(6000);
					});
					
					var args = msg.content.split(" ").slice(0);
					
					var message = msg.content.split(" ").slice(2).join(" ");
					
					var userID = args[1];
					
					var error1 = "Task Failed Successfully!"
					
					let guild = bot.guilds.get(config.SERVER_ID);
					
					if(isNaN(userID)) return msg.channel.send("Please user a proper User ID!").then(msg =>{
						msg.delete(6000);
					});
					if(!args[2]) return msg.channel.send("You cannot send an empty message!").then(msg =>{
						msg.delete(6000);
					});
					if(!guild.member(userID)) return msg.channel.send("That user is not in the server!").then(msg =>{
						msg.delete(6000);
					});
					
					var userName = bot.users.get(userID).tag

        var embed = new Discord.RichEmbed()

            .setColor(config.BLUE)

	.setTitle("Direct Message | EvilCraftRealm")

            .setDescription(message)

            .setFooter("Replies to this message will be forwarded to the admins")
          
            .setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")

//awaits confirmation here
let sendid = msg.author.id
const filter = m => m.author.id == msg.author.id

msg.channel.send("Is the following message correct? ``yes/no``", embed).then(() => {
	msg.channel.awaitMessages(filter, {
		maxMatches: 1,
		time: 10000,
		errors: ['time']
		
		}).then(collected => {
		if(collected.first().content === ("yes")) {

msg.channel.send("Message was sent!")
		bot.users.get(userID).send(embed).catch(console.log(`Message was sent to ${userName}!`))
		
		}else
		if(collected.first().content === ("no")) return msg.channel.send("Canceled!")
	}).catch(err => {
		msg.channel.send(`${error1}`)
	})
})
				}
			}
}