module.exports = async (bot, msg, args) => {
	msg.reply("hi")
}

module.exports.config = {
	name: "help"
	aliases: ["h", "hlp"]
}