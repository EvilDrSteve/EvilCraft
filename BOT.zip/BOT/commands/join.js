module.exports = {
	
	name: 'join',
	decription: 'Counts join and leave messages',
	execute(){
	
	const config = require("../config.json")
	const fs = require('fs')
	
	let rawdata = fs.readFileSync('joindata.json'); let data = JSON.parse(rawdata); console.log(data);
	
bot.on('message', msg => {
	
	if(msg.author.bot) return;
	
	if(msg.channel.name !== "general") return;
	if(!msg.member.roles.find(r => r.name === "EvilCraft")) return

	if(!data[msg.author.tag]) {
					data[msg.author.tag] = {
						Joins: 0,
						Leaves: 0
					}
					fs.writeFileSync("./joindata.json", JSON.stringify(data), (err=>{
						if(err) return console.log(err)
					}))
     }
 if(!data["total"]) {
 	data["total"] = {
 		Joins: 0,
 		Leaves: 0
 	}
 	fs.writeFileSync("./joindata.json", JSON.stringify(data), (err => {
 		if(err) return console.log(err)
 	}))
 	console.log(data)
 }
	
		if(msg.content == "?join") {
	
	if(!msg.member.roles.find(r => r.name === "EvilCraft")) return 
	
	if(data[msg.author.tag].Joins !== data[msg.author.tag].Leaves) return msg.channel.send("You havent ended the previous join session!").then(m => m.delete(5000)).then(msg.delete(0))
				
				data[msg.author.tag].Joins = data[msg.author.tag].Joins + 1;
				
				data["total"].Joins= data["total"].Joins + 1;
				
				fs.writeFileSync("./joindata.json", JSON.stringify(data), (err)=>{
		if(err) console.log(err)
	})
	msg.delete(0)
	}

			if(msg.content == "?leave") {
				
				if(!msg.member.roles.find(r => r.name === "EvilCraft")) return
				
				if(data[msg.author.tag].Leaves == data[msg.author.tag].Joins) return msg.channel.send("You have already left the game!").then(m => m.delete(5000)).then(msg.delete(0))
	
					data[msg.author.tag].Leaves =
					data[msg.author.tag].Leaves + 1;
					
					data["total"].Leaves = data["total"].Leaves + 1;
					fs.writeFileSync("./joindata.json", JSON.stringify(data), (err)=>{
		if(err) console.log(err)
	})
	msg.delete(0).catch(err => {if(err)return console.log(err)})
				}

			if(msg.content == "?data") {
				
				if(!msg.member.roles.find(r => r.name === "EvilCraft")) return
				
				if(!data[msg.author.tag]) return msg.channel.send("No data to show");
				
				var embed = new Discord.RichEmbed()
				.setColor(config.RED)
				.setTitle(`${msg.author.username} | Realm Activity`)
				.setDescription(`Join count: ${data[msg.author.tag].Joins}\nLeave count: ${data[msg.author.tag].Leaves}`)
				.setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")
				
				msg.channel.send(embed).then(m => m.delete(50000))
				msg.delete(0)
  	  }
  	  
  	if(msg.content == "?total data") {
  		
  		if(!msg.member.roles.find(r => r.name === "Admins")) return
  		
  		var embed = new Discord.RichEmbed()
				.setColor(config.RED)
				.setTitle(`Total Data | Realm Activity`)
				.setDescription(`Total Join count: ${data["total"].Joins}\nTotal Leave count: ${data["total"].Leaves}`)
				.setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")
				
				msg.channel.send(embed).then(m => m.delete(50000))
				msg.delete(0)
  	}
  	
  	if(msg.content.startsWith("?joinfor")) {

if(!msg.member.roles.find(r => r.name === "Admins")) return;

if(!msg.mentions.users.first() || msg.mentions.users.first().bot) return msg.channel.send("Please mention a Member")

	if(!msg.mentions.members.first().roles.find(r => r.name === "EvilCraft")) return msg.channel.send("That user isnt a realm member!")
	
	if(!msg.mentions.users.first()) return msg.channel.send("Please mention a Member!")
	
	let mention = msg.mentions.users.first().tag
	
	
	if(!data[mention]) {
		data[mention] = {
			Joins: 0,
			Leaves: 0
		}
	}
	
	if(data[mention].Joins !== data[mention].Leaves) return msg.channel.send("You havent ended the previous join session!").then(m => m.delete(5000)).then(msg.delete(0))
				
				data[mention].Joins = data[mention].Joins + 1;
				
				data["total"].Joins= data["total"].Joins + 1;
				
				fs.writeFileSync("./joindata.json", JSON.stringify(data), (err)=>{
		if(err) console.log(err)
	})
	msg.delete(0)
	}

			if(msg.content.startsWith("?leavefor")) {
				
				
				if(!msg.member.roles.find(r => r.name === "Admins")) return;

				
				if(!msg.mentions.users.first() || msg.mentions.users.first().bot) return msg.channel.send("Please mention a Member")
				
				if(!msg.mentions.members.first().roles.find(r => r.name === "EvilCraft")) return msg.channel.send("That user isnt a realm member!")
				
				if(!msg.mentions.users.first()) return msg.channel.send("Please mention a Member!")
	
	let mention = msg.mentions.users.first().tag
	
				if(!data[mention]) {
		data[mention] = {
			Joins: 0,
			Leaves: 0
		}
	}
	
				if(data[mention].Leaves == data[mention].Joins) return msg.channel.send("You have already left the game!").then(m => m.delete(5000)).then(msg.delete(0))
	
					data[mention].Leaves =
					data[mention].Leaves + 1;
					
					data["total"].Leaves = data["total"].Leaves + 1;
					fs.writeFileSync("./joindata.json", JSON.stringify(data), (err)=>{
		if(err) console.log(err)
	})
	msg.delete(0).catch(err => {if(err)return console.log(err)})
				}

if(msg.content.startsWith("?data")) {
				
				if(!msg.member.roles.find(r => r.name === "Admins")) return
		
		if(!msg.mentions.users.first() || msg.mentions.users.first().bot) return msg.channel.send("Please mention a Member")
				if(!msg.mentions.members.first().roles.find(r => r.name === "EvilCraft")) return msg.channel.send("That user isnt a realm member!")
				
				let mention = msg.mentions.users.first().tag
				
				if(!data[mention]) return msg.channel.send("No data to show");
				
				var embed = new Discord.RichEmbed()
				.setColor(config.RED)
				.setTitle(`${msg.mentions.users.first().username} | Realm Activity`)
				.setDescription(`Join count: ${data[mention].Joins}\nLeave count: ${data[mention].Leaves}`)
				.setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")
				
				msg.channel.send(embed).then(m => m.delete(50000))
				msg.delete(0)
  	  }
  	 })
  }
 }