module.exports = {
	name: 'start',
	description: 'to start the bot',
	execute(){
		bot.on('ready', async() => {
	
	console.log('Bot is now online');	
	bot.user.setActivity("0 players play on EvilCraftRealm", {type:"WATCHING"});
})

//count join and leave messages
bot.commands.get('curPlaying').execute();

bot.on('message', msg => {
	
	if(msg.author.bot) return
	
	let args = msg.content.substring(config.PREFIX.length).split(" ");
		
switch (args[0]){
			
			case 'dm': bot.commands.get('dm').execute(msg, args);
			break;
			
			case 'cq':
			bot.commands.get('cq').execute(msg, args);#
			break;
		}
})
	}
	
}

module.exports.config = {
	name: "start",
	aliases: ["s", "st"]
}