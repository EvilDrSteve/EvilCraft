module.exports = {
	
		name: 'ping',
		description: "says pong!",
		execute(msg, args){
			msg.channel.send("Pong")
			}
}