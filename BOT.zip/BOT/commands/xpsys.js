module.exports = {

 name: 'xpsys',
 description: 'Gives cookies for messages',
execute(msg, args){
	let cookie = require("./cookies.json");
	
	if(msg.author.bot) return;
		
	if(!cookie[msg.author.id]){
		cookie[msg.author.id] = {
			Cookies: 1
		}
		let Userbal = cookie[msg.author.id].Cookies
	}
	if(!msg.content.startsWith(PREFIX)){
		cookie[msg.author.id].Cookies = cookie[msg.author.id].Cookies + 1;
	
	fs.writeFile("./cookies.json", JSON.stringify(cookie), (err)=>{
		if(err) console.log(err)
	})
			console.log(`${cookie[msg.author.id]}`)
	console.log("xpsys executed");
	msg.reply(`${cookie[msg.author.id].Cookies}`).then(msg => {
		msg.delete(1000)
	});
}
}
}