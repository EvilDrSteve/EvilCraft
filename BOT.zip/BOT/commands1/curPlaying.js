module.exports = {
	
	name: "curPlaying",
	execute() {
	
	console.log("curplaying")
	
	const config = require("../config.json")
	const fs = require('fs')
	
	let rawdata = fs.readFileSync('playdata.json'); let data = JSON.parse(rawdata); console.log(data);
	
		bot.on('message', msg => {
			
			if(msg.author.bot) return;
			if(!msg.member.roles.find(r => r.name === "EvilCraft")) return;
			
				if(!data[msg.author.id]){
				data[msg.author.id] = {
					ingame: 0,
					message: 0
				}
			}
			
			if(!data["playing"]){
				data["playing"] = {
					 now: 0
				}
			}
			
			if(msg.content === "?play"){
				
			user = msg.author
			channel = msg.channel.name
			if(data[user.id].ingame !== 0) return msg.channel.send("You are already in a game!")
			 bot.guilds.get(config.SERVER_ID).channels.get("711048304502374493").send(`${user} joined the realm`).then(m => {
			 	data[user.id].ingame = 1
			 	data[user.id].message = m.id
			 	data["playing"].now = data["playing"].now + 1
			 	
			 					fs.writeFileSync("./playdata.json", JSON.stringify(data), (err=>{
						if(err) return console.log(err)
					}))
					bot.channels.get("711048304502374493").setName(`**Now Playing ${data["playing"].now}**`)
					
if(data["playing"].now <= 1)	{
bot.user.setActivity(`with ${data["playing"].now} Person`);
}else {
	bot.user.setActivity(`with ${data["playing"].now} People`);
}
					})
					console.log(data)
			 }
		
		if(msg.content === "?leave") {
			
			user = msg.author
			channel = msg.channel.name
			
			if(data[user.id].ingame !== 1) return msg.channel.send("You cant leave a game if you havent joined one!")
			
			bot.guilds.get(config.SERVER_ID).channels.get("711048304502374493").fetchMessage(data[user.id].message).then(m => m.delete(0))
			
			data[user.id].ingame = 0
			data[user.id].message = 0
			data["playing"].now = data["playing"].now - 1
			
			fs.writeFileSync("./playdata.json", JSON.stringify(data), (err=>{
						if(err) return console.log(err)
						}))
						bot.channels.get("711048304502374493").setName(`playing-${data["playing"].now}`)

if(data["playing"].now !== 0) {
	
	bot.user.setActivity(`with ${data["playing"].now} People`);
}else
{
	bot.user.setActivity(`Alone`);
}
		}
		
		if(msg.content.startsWith("?play")) {
				
			user = msg.mentions.users.first()
			channel = msg.channel.name
			
			if(!data[user.id]){
				data[user.id] = {
					ingame: 0,
					message: 0
				}
			}
			
			if(data[user.id].ingame !== 0) return msg.channel.send("You are already in a game!")
			 bot.guilds.get(config.SERVER_ID).channels.get("711048304502374493").send(`${user} joined the realm`).then(m => {
			 	data[user.id].ingame = 1
			 	data[user.id].message = m.id
			 	data["playing"].now = data["playing"].now + 1
			 	
			 					fs.writeFileSync("./playdata.json", JSON.stringify(data), (err=>{
						if(err) return console.log(err)
					}))
					bot.channels.get("711048304502374493").setName(`**Now Playing ${data["playing"].now}**`)
					
if(data["playing"].now <= 1)	{
bot.user.setActivity(`with ${data["playing"].now} Person`);
}else {
	bot.user.setActivity(`with ${data["playing"].now} People`);
}
					})
					console.log(data)
			 }
		
			 })
	}
}

module.exports.config = {
	name: "curPlaying",
	aliases: [],
	description: "Used to display currently online players"
}