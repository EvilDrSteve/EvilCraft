const Discord = require('discord.js');
const bot = new Discord.Client();
const config = require("./config.json");
const math = require('math.js');
const countryList = require("./countryList.json");
const currentlyPlaying = require("./currentlyPlaying.txt");
const fs = require('fs');
//var lastLetter = require('./lastLetters.txt');

let rawdata = fs.readFileSync('./gamedata.json')
let data = JSON.parse(rawdata); console.log(data);

var PREFIX = '.';
	
bot.on('message', (message) => {
	
	if(!data["game"]) {
		data["game"] = {
			on: 0,
			lastLetter: "a"
		}
	}
	
	
	if (message.content == ".cq quit"){
	       data["game"].on = 0;
	       fs.writeFileSync('./gamedata.json', JSON.stringify(data))
	       message.channel.send("you are no longer playing")}
	       
 	if (message.content == ".cq play"){
	       data["game"].on = 1;
	       fs.writeFileSync('./gamedata.json', JSON.stringify(data))
	       message.channel.send("you are now playing")}
	       
	
	if (data["game"].on == 1){
	
  if (!message.author.bot && message.author.id == '332140653725089792') {

  	   var country = message.content;
  
      var firstLetter = message.content.toLowerCase().charAt(0);
      
      if (!data["game"].lastLetter){
      	data["game"].lastLetter = "a"
      }
      

     
      if (!message.content.startsWith(data["game"].lastLetter)){
            return message.channel.send(`That does not start with ${data["game"].lastLetter}`)}
      
  	if ((countryList.COUNTRY_LIST.some(word => message.content.toLowerCase() == word))) {
  		
  		      data["game"].lastLetter = message.content.toLowerCase().slice(-1);

  	message.channel.send(`You Guessed ${country}!, Now think of a country that starts from ${data["game"].lastLetter}`)
fs.writeFileSync('./gamedata.json', JSON.stringify(data));
  	
 }
 
 else if (!message.author.bot && message.author.id == '332140653725089792' && message.content !== ".cq play") {
  message.channel.send("not a country")
  }
 
  	   }
  	  
  	  }
  
  
 });

bot.on('ready', async() => {

	console.log('The Bot is online!');	
	bot.user.setActivity("Slavery", {type:"WATCHING"}

})

bot.on('message',(message) => {
 
 if(message.content == 'Test') {

     message.reply('I am Online!')}
  });


bot.login("NzA2OTU0ODc1MjU0MzQxNzUz.XrBzDA.ckH65B3Nfff8OZsbpmt9gn5LUzI");




function makeid(length) {
	 var result = '';
	 var characters = 'abcdefghijklmnopqrstuvwxyz';
	 var charactersLength = characters.length;
result += characters.charAt(Math.floor(Math.random() * charactersLength));
return result; } 
