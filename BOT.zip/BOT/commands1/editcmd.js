const fs = require('fs')
const config = require('../config.json')

module.exports.run = async (bot, msg, args) => {
	
	if(!msg.content.startsWith(config.PREFIX)) return
	if(msg.author.bot) return;
 if(!args[0])	return
 if(!args[1]) return msg.channel.send("You cant leave the embed body empty!")
 if(args[0] == "help") return msg.channel.send("```.testedit <command> <Title> <Body>```")
	let rawdata = fs.readFileSync('./commands1/test.json')
let data = JSON.parse(rawdata); console.log(data);

var command = args.shift()

if(!data[command]) return msg.channel.send("There isnt a command with that name!")


data[command].undo = data[command].stuff
data[command].stuff = args.join(" ")
console.log(`${data[command].stuff}`)
var Title = data[command].stuff.split(" ").slice(0)[0]

var embed = new Discord.RichEmbed()
										.setTitle(`${Title} | Realm`)
										.setColor(config.RED)
										.setDescription(`${data[command].stuff.split(" ").slice(1).join(" ")}`)
										.setFooter("The server Prefix is .")
										.setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")
										
				let sendid = msg.author.id
const filter = m => m.author.id == msg.author.id

msg.channel.send("Is the following message correct? ``yes/no``", embed).then(() => {
	msg.channel.awaitMessages(filter, {
		maxMatches: 1,
		time: 10000,
		errors: ['time']
		
		}).then(collected => {
		if(collected.first().content === ("yes")) {

fs.writeFileSync('./commands1/test.json', JSON.stringify(data))
msg.channel.send("Edit Completed!")
		
		}else
		if(collected.first().content === ("no")) return msg.channel.send("Canceled!")
	}).catch(err => {
		msg.channel.send(`Task failed successfully`)
	})
})
}

module.exports.config = {
	name: "editcmd",
	aliases: ["ecmd"]
}