const config = require("../config.json")
const fs = require('fs')


module.exports.run = async (bot, msg, args) => {
			
			if(!msg.content.startsWith(config.PREFIX)) return
			
			let rawdata = fs.readFileSync('./playdata.json'); let data = JSON.parse(rawdata); console.log(data);
			
			
			if(msg.author.bot) return;
			if(!msg.member.roles.find(r => r.name === "EvilCraft")) return;

   if(!args[0]) return msg.channel.send(`Your GT is: **${data[msg.author.id].gt}**`)
   
  data[msg.author.id].gt = args.join(" ")
  
  fs.writeFileSync("./playdata.json", JSON.stringify(data), (err => {
  	if(err) return msg.channel.send("Task failed successfully!")
  }))
   msg.channel.send(`Set your GT to __**${data[msg.author.id].gt}**__`)
}


module.exports.config = {
	name: "gt",
	aliases: []
}