const config = require('../config.json')

module.exports.run = async (bot,msg,args) => {
	if(!msg.content.startsWith(config.PREFIX)) return
	msg.reply("hi")
}

module.exports.config = {
	name: "help",
	aliases: ["h", "hlp"]
}