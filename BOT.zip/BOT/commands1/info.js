const fs = require('fs');
const config = require('../config.json')
const discord = require('discord.js')

module.exports.run = async (bot, msg, args) => {
	
	if(!msg.content.startsWith(config.PREFIX)) return
	if(msg.author.bot) return
	
	let rawdata = fs.readFileSync('./commands1/test.json')
let data = JSON.parse(rawdata); console.log(data);
	
	if(!data["info"]){
	data["info"] = {
		stuff: 0,
		undo: 0,
		backup: 0
	}
		fs.writeFileSync('./commands1/test.json', JSON.stringify(data))
}
	var Title = data["info"].stuff.split(" ").slice(0)[0]

var embed = new Discord.RichEmbed()
										.setTitle(`${Title} | Realm`)
										.setColor(config.RED)
										.setDescription(`${data["info"].stuff.split(" ").slice(1).join(" ")}`)
										.setFooter("The server Prefix is .")
										.setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")
	
	msg.channel.send(embed)
	
}

module.exports.config = {
	name: "info",
	aliases: []
}