const config = require("../config.json")
const fs = require('fs')


module.exports.run = async (bot, msg, args) => {
			
			if(!msg.content.startsWith(config.PREFIX)) return
			
			let rawdata = fs.readFileSync('commands1/points.json'); let data = JSON.parse(rawdata); console.log(data);

if(!data[msg.author.id]){
	data[msg.author.id] = {
		count: 0,
		min: 0
	}
}

var embed = new Discord.RichEmbed()
 .setColor(config.RED)
	.setTitle(`GrabCraft`)
//	.setDescription("**Joined the Realm**")
 .addField('Playing For', "0 Minutes")
	//.setThumbnail(user.avatarURL)
	.setFooter("Test")
	.setTimestamp()
	.setImage('https://www.grabcraft.com/random')
	
	msg.channel.send(embed)
let user = msg.author
let count = 0
let min = 0
data[user.id].count = count
data[user.id].min = min

msg.channel.send("0")	.then(m => {
const counter = setInterval(() => {
	 if (count < 10) {
	 	 console.log(count)
	 	 count++ 
	 	 m.edit(count)
	 	 }
	 	  else {
	 	 	 clearInterval(counter)
	 	 	 min++
	 	 	 console.log(min)
	 	 	 count = 0
	 	 	// m.edit(count)
	 	 	 
	 	 	  }
	 	 }, 1000 * 10)
	})
	}
module.exports.config = {
	name: "test",
	aliases: ["t"]
}