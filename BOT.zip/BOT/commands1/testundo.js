const fs = require('fs')
const config = require('../config.json')

module.exports.run = async (bot, msg, args) => {

if(!msg.content.startsWith(config.PREFIX)) return
	if(msg.author.bot) return;
 if(!args)	return

	let rawdata = fs.readFileSync('./commands1/test.json')
let data = JSON.parse(rawdata); console.log(data);

if(!data["info"]){
	data["info"] = {
		stuff: 0,
		undo: 0,
		backup: 0
	}
}

data["info"].backup = data["info"].stuff
data["info"].stuff = data["info"].undo
data["info"].undo = data["info"].backup

fs.writeFileSync('./commands1/test.json', JSON.stringify(data))
msg.channel.send("Undo Completed!")
}

module.exports.config = {
	name: "testundo",
	aliases: []
}