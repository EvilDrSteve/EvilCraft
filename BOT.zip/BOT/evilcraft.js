const Discord = require('discord.js');

const bot = new Discord.Client();

const config = require("./config.json");

bot.on('ready', async() => {

	console.log('Bot is now online');	
	bot.user.setActivity("on EvilCraftRealm", {type:"PLAYING"})

})

bot.on('message',(message) => {
 
 if(message.channel.type !== "dm") {

 if(message.content == 'Cat') {

     message.reply('Meow')

 }


//mute command


 /* if (message.content.startsWith(config.PREFIX + "mute")) {

   var args = message.content.split(" ").slice(1)

   var user = args[1]


     message.channel.send ('${user}')
  

}
*/
/*

 if (message.content.startsWith(config.PREFIX + "test")) {
	

        if (!message.member.roles.find(r => r.id === "312194307090153472")) return message.reply('❌ You don\'t have permission to use this command')

        var args = message.content.split(" ").slice(0)

        //var Rargs = message.content.split(" ").slice(3).join(" ")
    
       userID = args[1] 
 
       userName = bot.users.get(userID).tag

        //userName = args[1]

        message.reply(userName)

}

    */


  if(message.content.includes("sharoo")) {

     message.react(message.guild.emojis.get("635188165333745696"))
  }


//reply command disabled

/* if (message.content.startsWith(config.PREFIX + "reply")) {
	

        if (!message.member.roles.find(r => r.id === "312194307090153472")) return message.reply('❌ You don\'t have permission to use this command')

        var args = message.content.split(" ").slice(0)

        var Rargs = message.content.split(" ").slice(2).join(" ")

        var userID = args[1]

        if (isNaN(args[1])) return message.reply("❌ This is not an ID! Make sure you are using the user's ID!")
	        if (!args[2]) return message.reply("❌ You cannot send an empty message!")

        var embed = new Discord.RichEmbed()

            .setColor(config.GREEN)

            .setAuthor("New Message", "https://cdn.discordapp.com/attachments/502649544622735362/520740243133956138/receive.png")
	
	.setTitle("**Message**:")

            .addBlankField(true)

            .setDescription(Rargs)

            .addBlankField(true)

            .setFooter("This message was sent by EvilCraft Admins","https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")

        bot.users.get(userID).send(embed).catch(console.log(`Message was sent to ${userID}!`))

        if (message.author.bot) return;

        message.channel.send("✉️ Your Message was Sent!").catch(console.error)
       .then(bot.guilds.get(config.SERVER_ID).channels.get("343075378568364042").send(`**${message.author.username} sent the following message to ${userID}**` ,embed))
    }else
 
*/   

    
//steves stuff here




//DM for accepted applications
    if (message.content.startsWith(config.PREFIX + "dm" + " " + "accept")) {
	

        if (!message.member.roles.find(r => r.name === "312194307090153472")) return message.reply('❌ You don\'t have permission to use this command')

        var args = message.content.split(" ").slice(1)

        var Rargs = message.content.split(" ").slice(3).join(" ")

        var userID = args[1]
     
       // error if user not in server var userName = bot.users.get(userID).tag

        if (isNaN(args[1])) return message.reply("❌ This is not an ID! Make sure you are using the user's ID!")
	       
           if (!args[2]) return message.reply("❌ You cannot send an empty message!")
        
   let guild = bot.guilds.get(config.SERVER_ID)

   if (guild.member(userID)){
  //there is a GuildMember with that ID

       
        var userName = bot.users.get(userID).tag

        var embed = new Discord.RichEmbed()

            .setColor(config.GREEN)

            //.setAuthor("Realm Application results", "https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")
	
	.setTitle("Applications | EvilCraftRealm")

            //.addBlankField(true)

            .setDescription(Rargs)

            //.addBlankField(true)

            .setFooter("Replies to this message will be forwarded to the admins")
            
            .setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")

        bot.users.get(userID).send(embed).catch(console.log(`Message was sent to ${userID}!`))

        if (message.author.bot) return;

        message.channel.send("Your Message was Sent!").catch(console.error)
        .then(bot.guilds.get(config.SERVER_ID).channels.get("343075378568364042").send(`**${message.author.username} sent the following message to ${userName}**` ,embed))

    }else
   
 return message.reply("That user is not in the server")

}else
    

//DM for rejected applications

    if (message.content.startsWith(config.PREFIX + "dm" + " " + "reject")) {
	

        if (!message.member.roles.find(r => r.id === "312194307090153472")) return message.reply('❌ You don\'t have permission to use this command')

        var args = message.content.split(" ").slice(1)

        var Rargs = message.content.split(" ").slice(3).join(" ")

        var userID = args[1]

        if (isNaN(args[1])) return message.reply("❌ This is not an ID! Make sure you are using the user's ID!")
	     
        if (!args[2]) return message.reply("❌ You cannot send an empty message!")


        let guild = bot.guilds.get(config.SERVER_ID)

    if (guild.member(userID)) {

       
        var userName = bot.users.get(userID).tag

        var embed = new Discord.RichEmbed()

            .setColor(config.RED)

            //.setAuthor("Realm Application results", "https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")
	
	.setTitle("Applications | EvilCraftRealm")

            //.addBlankField(true)

            .setDescription(Rargs)

            //.addBlankField(true)

            .setFooter("Replies to this message will be forwarded to the admins")
          
            .setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")

        bot.users.get(userID).send(embed).catch(console.log(`Message was sent to ${userName}!`))

        if (message.author.bot) return;

        message.channel.send("Your Message was Sent!").catch(console.error)
        .then(bot.guilds.get(config.SERVER_ID).channels.get("343075378568364042").send(`**${message.author.username} sent the following message to ${userName}**` ,embed))

  }else
   
      return message.reply ("This User is not in the server")

}else

    

// Normal DM

    if (message.content.startsWith(config.PREFIX + "dm")) {
	

        if (!message.member.roles.find(r => r.id === "312194307090153472")) return message.reply('❌ You don\'t have permission to use this command')

        var args = message.content.split(" ").slice(0)

        var Rargs = message.content.split(" ").slice(2).join(" ")

        var userID = args[1]

        if (isNaN(args[1])) return message.reply("❌ This is not an ID! Make sure you are using the user's ID!")
	      
        if (!args[2]) return message.reply("❌ You cannot send an empty message!")

        let guild = bot.guilds.get(config.SERVER_ID)
  
    if (guild.member(userID)) {


        var userName = bot.users.get(userID).tag

        var embed = new Discord.RichEmbed()

            .setColor(config.BLUE)

            //.setAuthor("Realm Application results", "https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")
	
	.setTitle("Direct Message | EvilCraftRealm")

            //.addBlankField(true)

            .setDescription(Rargs)

            //.addBlankField(true)

            .setFooter("Replies to this message will be forwarded to the admins")

            .setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")

        bot.users.get(userID).send(embed).catch(console.log(`Message was sent to ${userID}!`))

        if (message.author.bot) return;

        message.channel.send("Your Message was Sent!").catch(console.error)
        .then(bot.guilds.get(config.SERVER_ID).channels.get("343075378568364042").send(`**${message.author.username} sent the following message to ${userName}**` ,embed))
   
   }else

   return message.reply ("This User is not in the Server")

}else


// Results post reject


if (message.content.startsWith(config.PREFIX + "post" + " " + "reject")) {
	

        if (!message.member.roles.find(r => r.id === "312194307090153472")) return message.reply('❌ You don\'t have permission to use this command')

        var args = message.content.split(" ").slice(1)

        var Rargs = message.content.split(" ").slice(3).join(" ")

        var userName = args[1]

        //if (isNaN(args[1])) return message.reply("❌ This is not an ID! Make sure you are using the user's ID!")
	      
        if (!args[0]) return message.reply("❌ You cannot send an empty message!")

       


        var embed = new Discord.RichEmbed()

            .setColor(config.RED)

            //.setAuthor("Realm Application results", "https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")
	
	.setTitle(`${userName} | Application Results`)

            //.addBlankField(true)

            .setDescription(Rargs)

            //.addBlankField(true)

           // .setFooter("Replies to this message will be forwarded to the admins")

            .setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")

      //  bot.users.get(userID).send(embed).catch(console.log(`Message was sent to ${userID}!`))

         bot.guilds.get(config.SERVER_ID).channels.get("706955756829933668").send(embed)
        
      if (message.author.bot) return;

        message.channel.send("Your Message was Sent!").catch(console.error)
        .then(bot.guilds.get(config.SERVER_ID).channels.get("343075378568364042").send(`**${message.author.username} posted the following message in <#706955756829933668>**` ,embed))
   

}else



// Results post accept


if (message.content.startsWith(config.PREFIX + "post" + " " + "accept")) {
	

        if (!message.member.roles.find(r => r.id === "312194307090153472")) return message.reply('❌ You don\'t have permission to use this command')

        var args = message.content.split(" ").slice(1)

        var Rargs = message.content.split(" ").slice(3).join(" ")

        var userName = args[1]

        //if (isNaN(args[1])) return message.reply("❌ This is not an ID! Make sure you are using the user's ID!")
	      
        if (!args[0]) return message.reply("❌ You cannot send an empty message!")

       


        var embed = new Discord.RichEmbed()

            .setColor(config.GREEN)

            //.setAuthor("Realm Application results", "https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")
	
	.setTitle(`${userName} | Application Results`)

            //.addBlankField(true)

            .setDescription(Rargs)

            //.addBlankField(true)

           // .setFooter("Replies to this message will be forwarded to the admins")

            .setThumbnail("https://cdn.discordapp.com/attachments/310408216611651584/611173978291044372/EvilCraft.png.png")

      //  bot.users.get(userID).send(embed).catch(console.log(`Message was sent to ${userID}!`))

         bot.guilds.get(config.SERVER_ID).channels.get("706955756829933668").send(embed)
        
      if (message.author.bot) return;

        message.channel.send("Your Message was Sent!").catch(console.error)
        .then(bot.guilds.get(config.SERVER_ID).channels.get("343075378568364042").send(`**${message.author.username} posted the following message in <#706955756829933668>**` ,embed))
   

}else

     if(message.content.startsWith(config.PREFIX + "notify")){
     	roleid = "312855958118203392"
      let role = message.guild.roles.find(r => r.name === "Notify"); 

     	let member = message.member
     //	if (message.member.roles.find(r => r.id === "708865720611635293"))  
     if(message.member.roles.has("708865720611635293")){ if(message.member.roles.find(r => r.name === "Notify")) {
     	member.removeRole(role)
     	message.channel.send("Removed the ``Notify`` Role") 
     }else
     {
     	member.addRole(role)
     	message.channel.send("Added the ``Notify`` Role")
     }
     }
}


}else
  
       if (message.channel.type === "") { 

        var args = message.content.split(" ").slice(0)

        var args = args.slice(0).join(" ")

        var BOT_ID = bot.user.id

        var userID = message.author.id

        if (message.content.startsWith(config.PREFIX)) return message.channel.send("❌ \nHey! \nThis is for messaging staff. For other commands use the server channels!") 

        if (message.author.bot) return;

        message.channel.send("✉️ Your message has been sent to the staff!")

        if (message.content.startsWith(config.PREFIX)) return

        if (args.length > 2048) return message.reply("❌ Your message could not be sent because it was too lengthy. Please split it into multiple messages (2048 Limit).") 

        var embed = new Discord.RichEmbed()

            .setColor(config.RED)

            .setAuthor("New Message", "https://cdn.discordapp.com/attachments/502649544622735362/520740243133956138/receive.png")
	
	    .setTitle("**Message**:")

            .addBlankField(true)

            .setDescription(args)

            .setFooter("This message was sent by: " + message.author.tag + " ", message.author.AvatarURL)

            .setTimestamp()

        bot.guilds.get(config.SERVER_ID).channels.get(config.CHANNEL_ID).send(embed).catch(console.log(`Message recieved from ${userID}!(${message.author.username})`))

        bot.guilds.get(config.SERVER_ID).channels.get(config.CHANNEL_ID).send({embed: {

            "description": `${config.PREFIX}dm ${message.author.id} <message>`,


          }

       })

    }

});


bot.login("NzA3NjY4Nzk4ODI3NjU5Mjc0.XrMedw.cAUb1n1I-GcWb48YZpS1u3Wy1_c")