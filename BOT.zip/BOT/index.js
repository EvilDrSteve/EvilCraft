const Discord = require('discord.js');

const bot = new Discord.Client();

const config = require("./config.json");

const PREFIX = '!';

let xp = require("./xp.json");

bot.on('ready', async() => {

	console.log('Bot is now online');	
	bot.user.setActivity("on EvilCraftRealm", {type:"PLAYING"})

})

/*	bot.on('message', msg=>{
	
			if(msg.content === "Hi"){
				msg.reply("Heya");			
			}
			
	}) */
	
	bot.on('message', msg=>{
	

//		var user = msg.author.username
		
		let args = msg.content.substring(PREFIX.length).split(" ");
		
		switch(args[0]){
			case 'ping':
						msg.reply("pong");
						break;
						
			case 'evilcraftrealm':
					msg.reply("its a realm")
					break;
					
			case 'help':
				if(args[1] === 'shops'){
					msg.reply("Here are the listed shops: 1 2 3 4 5")
					console.log("Help command used by ${msg.author.username}")
					
				}
				break;
				
		 case 'xp':
		 			let xpAdd = Math.floor(Math.random() * 7) + 8;
		console.log(xpAdd)
		
					if(!xp[msg.author.id]){
						xp[msg.author.id] = {
							xp: 0,
							level: 1	
						};					
					}
	
	     xp[msg.author.id].xp = xp[msg.author.id] + xpAdd;
	     
	     let nextLvl = xp[msg.author.id].level * 300;
	     
	     if(nextLvl <= xp[msg.author.id].xp){
	     	xp[msg.author.id].level = xp[msg.author.id].level + 1;
	   
	     }
				console.log(`level is ${xp[msg.author.id].level}`)
			  	fs.writeFile("./xp.json", JSON.stringify(xp), (err) => {
	     		if(err) console.log(err)
	     		
	     	})	
		}
		
	})


bot.login("NzA3NjY4Nzk4ODI3NjU5Mjc0.XrMedw.cAUb1n1I-GcWb48YZpS1u3Wy1_c")