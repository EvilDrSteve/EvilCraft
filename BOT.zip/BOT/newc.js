const Discord = require('discord.js');
const bot = new Discord.Client();
const config = require("./config.json");
const PREFIX = '!';

const fs = require('fs');
bot.commands = new Discord.Collection();

const commandFiles = fs.readdirSync('./commands/').filter(file => file.endsWith('.js'));
for(const file of commandFiles){
	const command = require(`./commands/${file}`);
	
	bot.commands.set(command.name, command)
}

let cookie = require("./cookies.json")

bot.on('ready', () => {
	console.log("Bot is online!")
});

bot.on('message', msg => {
	
	let args = msg.content.substring(PREFIX.length).split(" ");
	bot.commands.get('xpsys').execute(msg, args);
	
	switch (args[0]){
		
		case 'test':
		bot.commands.get('test').execute(msg, args);
		break;
	}
})




bot.login("NzA3NjY4Nzk4ODI3NjU5Mjc0.XrMedw.cAUb1n1I-GcWb48YZpS1u3Wy1_c")