const Discord = require('discord.js');
const bot = new Discord.Client();
const config = require("./config.json");
const PREFIX = '!';

let ship = require("./ship.json");

bot.on('ready', () => {
	console.log("Bot is ready")
});

bot.on('message', msg => {
	let args = msg.content.substring(PREFIX.length).split(" ");
	
	mention1 = msg.author.id;
	mention2 = msg.mentions.users.first().id
	
	if(!ship[mention1].mention2){
	ship[mention1] = {
		mention2: 1
	}
	fs.writeFile("./ship.json", JSON.stringify(ship), err =>{
		if(err) console.log(err)
	})
	msg.reply("50%")
	}else{
		msg.reply(`{ship[mention1].mention2
		}`)
	}
})



bot.login("NzA3NjY4Nzk4ODI3NjU5Mjc0.XrMedw.cAUb1n1I-GcWb48YZpS1u3Wy1_c")